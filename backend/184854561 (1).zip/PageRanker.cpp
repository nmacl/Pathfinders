#include <map>
#include <string>
#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <stdexcept>

// Site struct contains data related to each website.
struct Site {
    double linkCount = 0.0;  // Number of outbound links.
    double siteRank = 0.0;   // PageRank of the site.
    double temporaryRank = 0.0;  // Temporary rank used during calculations.
    int id;  // Unique ID of the site.
};

class Web {
    // webGraph maps a site name to a pair of Site struct and a vector of its links.
    std::map<std::string, std::pair<Site, std::vector<std::string>>> webGraph;
    double totalSites = 0;  // Total number of sites in the web.

public:
    void createLink(const std::string& source, const std::string& target);

    // Function to compute PageRank of all sites.
    void computeRank(int iterations);

private:
    // Helper function 
    void validateAndCreateSite(const std::string& siteName);
};

void Web::createLink(const std::string& source, const std::string& target) {
    if (source.empty() || target.empty()) return;

    validateAndCreateSite(source);
    validateAndCreateSite(target);

    // Add target to source's links 
    if (std::find(webGraph[source].second.begin(), webGraph[source].second.end(), target) == webGraph[source].second.end()) {
        webGraph[source].second.push_back(target);
        webGraph[source].first.linkCount += 1.0;
    }
}

void Web::validateAndCreateSite(const std::string& siteName) {
    if (webGraph.find(siteName) == webGraph.end()) {
        webGraph[siteName].first.id = totalSites++;
    }
}

void Web::computeRank(int iterations) {
    if (iterations <= 0 || webGraph.empty()) throw std::invalid_argument("Iterations should be more than 0 and webGraph should not be empty.");

    std::vector<double> ranks(static_cast<int>(totalSites), 1.0 / totalSites);

    for (auto& site : webGraph) {
        site.second.first.siteRank = 1.0 / totalSites;
    }

    // Perform PageRank calculations for specified iterations.
    while (--iterations) {
        for (auto& site : webGraph) {
            double update = 0.0;
            if (site.second.first.linkCount == 0) {  // Dangling page.
                update = ranks[site.second.first.id] / totalSites;
            }
            else {
                update = ranks[site.second.first.id] / site.second.first.linkCount;
            }
            for (const auto& link : site.second.second) {
                webGraph[link].first.temporaryRank += update;
            }
        }

        for (auto& site : webGraph) {
            site.second.first.siteRank = site.second.first.temporaryRank;
            ranks[site.second.first.id] = site.second.first.siteRank;
            site.second.first.temporaryRank = 0.0;
        }
    }

    // Print PageRank of each site.
    for (const auto& site : webGraph) {
        std::cout << site.first << " " << std::fixed << std::setprecision(2) << site.second.first.siteRank << std::endl;
    }
}

int main() {
    Web web;
    int linkCount, iterations;

    // Read the number of links and iterations.
    if (!(std::cin >> linkCount >> iterations) || linkCount <= 0 || iterations <= 0) {
        std::cerr << "Invalid input\n";
        return 1;  // Return an error code
    }

    // Read and create links.
    while (linkCount--) {
        std::string source, target;
        if (!(std::cin >> source >> target)) {
            std::cerr << "Invalid input\n";
            return 1;  // Return an error code
        }
        web.createLink(source, target);
    }

    // Compute PageRank.
    try {
        web.computeRank(iterations);
    }
    catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;  // Return an error code
    }

    return 0;
}
